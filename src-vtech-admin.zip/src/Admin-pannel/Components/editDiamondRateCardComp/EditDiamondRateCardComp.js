import React from 'react'
import AddDiamondRateCardComp from '../addDiamonRateCardComp/AddDiamondRateCardComp'

function EditDiamondRateCardComp() {
    return (
        <>
            <AddDiamondRateCardComp />
        </>
    )
}

export default EditDiamondRateCardComp