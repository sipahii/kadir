import React from 'react'
import AddCelebritiesPackagePage from '../../Pages/addCelebrityPackagePage'

function EditCelebrityPackageComp() {
    return (
        <>
            <AddCelebritiesPackagePage />
        </>
    )
}

export default EditCelebrityPackageComp