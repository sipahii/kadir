import React from 'react'
import AddColorStoneRateCardComp from '../addColorStoneRateCardComp/AddColorStoneRateCardComp'

function EditColorStoneRateCardComp() {
    return (
        <>
            <AddColorStoneRateCardComp />
        </>
    )
}

export default EditColorStoneRateCardComp