import React from 'react'
import AddMetalRateCardPage from '../../Pages/addMetalRateCardpage'

function EditMetalRateCardComp() {
    return (
        <>
            <AddMetalRateCardPage />
        </>
    )
}

export default EditMetalRateCardComp