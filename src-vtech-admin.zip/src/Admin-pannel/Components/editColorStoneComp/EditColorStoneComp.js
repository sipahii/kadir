import React from 'react'
import AddColorStone from '../../Components/generalMaster/colorStone/addColorStone/AddColorStone'

function EditColorStoneComp() {
    return (
        <>
            <AddColorStone />
        </>
    )
}

export default EditColorStoneComp