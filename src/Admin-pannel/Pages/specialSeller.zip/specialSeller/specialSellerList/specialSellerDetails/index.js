import SpecialSellerDetails from "../../../../Components/specialSeler/specialSellerDetails/SpecialSellerDetails"

function SpecialSellerDetailsPage() {
    return (
        <>
            <SpecialSellerDetails />
        </>
    )
}
export default SpecialSellerDetailsPage