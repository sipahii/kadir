import axios from "axios"
import { useState } from "react"
import { Link } from "react-router-dom"
import { base_Url } from "../../../../server"
import { useEffect } from "react"
import { GrView } from 'react-icons/gr'
import ReactHTMLTableToExcel from 'react-html-table-to-excel';


function SpecialSellerList() {

    const token = window.localStorage.getItem('token')

    const [listSeller, setListSeller] = useState(null)
    const [statusList, setStatusList] = useState(null)
    const [categoryy, setCategoryy] = useState(null)
    // console.log(statusList);

    const [searchList, setSearchList] = useState({
        start_date: null,
        end_date: null,
        // searchInput: null,
        firstname: null,
        lastname: null,
        email: null,
        mobile: null,
        application: null,
        udid: null,
        adharnumber: null,
        status: null,
        minDOB: null,
        maxDOB: null,
        category: null
        // searchType: null,
        // status: null,
    })

    const handleChangeSearch = (e) => {
        const clone = { ...searchList }
        const value = e.target.value
        const name = e.target.name
        clone[name] = value
        setSearchList(clone)
    }

    const statusSelect = async () => {
        try {
            const res = await axios.get(`${base_Url}specialSeller/statusList`, {
                withCredentials: true,
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: `Bearer ${token}`,
                },
            })
            setStatusList(res?.data.status)
        } catch (error) {

        }
    }

    const postSearchList = async () => {
        try {
            const res = await axios.post(`${base_Url}specialSeller/filter`, searchList, {
                withCredentials: true,
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: `Bearer ${token}`,
                },
            })
            setListSeller(res.data)
            if (res.data?.status == 500) {
                alert(res.data.message)
            }

        } catch (error) {

        }
    }

    const getSpecialSeller = async () => {
        try {
            const res = await axios.get(`${base_Url}specialSeller`, {
                withCredentials: true,
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: `Bearer ${token}`,
                },
            })
            setListSeller(res?.data)
        } catch (error) {

        }
    }

    const getCategory = async () => {
        try {
            const res = await axios.get(`${base_Url}category/admin/child/${25}`, {
                withCredentials: true,
                headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: `Bearer ${token}`,
                },
            })
            setCategoryy(res?.data);
        } catch (error) {

        }
    }
    const handleDelete = async (id) => {
        const res = await axios.delete(`${base_Url}specialSeller/delete_seller/${id}`, {
            withCredentials: true,
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: `Bearer ${token}`,
            },
        })
        getSpecialSeller()
    }

    useEffect(() => {
        getSpecialSeller()
        statusSelect()
        getCategory()
    }, [])
    return (
        <>
            <div className="aiz-main-content">
                <div className="px-15px px-lg-25px">
                    <div className="aiz-titlebar text-left mt-2 mb-3">
                        <div className="row align-items-center">
                            <div className="col-md-6">
                                <h1 className="h3">Special Seller List</h1>
                            </div>
                            {/* <div className="col-md-6 text-md-right">
                                <Link to="/admin/roles/create" className="btn btn-circle btn-info">
                                    <span>Add New Role</span>
                                </Link>
                            </div> */}
                        </div>
                    </div>
                    <div className="card">
                        <div className="card-header">
                            <h5 className="mb-0 h6">Special Seller List</h5>
                            {/* <div className="col-md-6 text-md-right">
                                <Link to="/admin/category-type/add" className="btn btn-circle btn-info">
                                    <span>Add Category</span>
                                </Link>
                            </div> */}
                        </div>
                        <div className="card-body">
                            <section className="form-section">
                                <div className="row">
                                    {/* <form action=""> */}
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Start Date</label>
                                            <input type="date" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name='start_date' value={searchList.start_date} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">End Date</label>
                                            <input type="date" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name='end_date' value={searchList.end_date} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">First Name</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="First Name" name='firstname' value={searchList.firstname} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Last Name</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Last Name" name='lastname' value={searchList.lastname} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Adhar Number</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Adhar Number" name='adharnumber' value={searchList.adharnumber} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Email</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" name='email' value={searchList.email} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Mobile</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Mobile" name='mobile' value={searchList.mobile} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Application No</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Application No" name='application' value={searchList.application} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">UDID Number</label>
                                            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="UDID Number" name='udid' value={searchList.udid} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Minimum DOB</label>
                                            <input type="date" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="UDID Number" name='minDOB' value={searchList.minDOB} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div>
                                            <label htmlFor="">Maximum DOB</label>
                                            <input type="date" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="UDID Number" name='maxDOB' value={searchList.maxDOB} onChange={handleChangeSearch} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <label htmlFor="">Category</label>
                                        <select class="form-select" aria-label="Default select example" name="categoryy" onChange={handleChangeSearch}>
                                            <option selected value={null}>Open this select menu</option>
                                            {categoryy && categoryy?.map((item) => {
                                                console.log('item', item)
                                                return <option value={item?._id}>{item?.name}</option>
                                            })}
                                        </select>
                                    </div>
                                    <div className="col-lg-3">
                                        <label htmlFor="">Status</label>
                                        <select class="form-select" aria-label="Default select example" name="status" onChange={handleChangeSearch}>
                                            <option selected value={null}>Open this select menu</option>
                                            {statusList && statusList?.map((item) => {
                                                // console.log('item', item)
                                                return <option value={item?._id}>{item?.name}</option>
                                            })}
                                        </select>
                                    </div>

                                    <div className="col-lg-3 mt-3">
                                        <button type="button" className="btn btn-primary mr-3 mt-2" onClick={postSearchList}>Search</button>
                                        {/* <button className="btn btn-danger">Rest</button> */}
                                    </div>
                                    {/* </form> */}
                                </div>
                            </section>
                            <ReactHTMLTableToExcel
                                id="test-table-xls-button"
                                className="download-table-xls-button"
                                table="table-to-xls"
                                filename="tablexls"
                                sheet="tablexls"

                                buttonText="Export to Excel sheet" />
                            <table className="table table-3" id="table-to-xls">
                                <thead>
                                    <tr>
                                        <th class="table-secondary" scope="col">Registration No</th>
                                        <th class="table-secondary" scope="col">Registration Date</th>
                                        <th class="table-secondary" scope="col">UDID No</th>
                                        <th class="table-secondary" scope="col">Adhaar Card</th>
                                        <th class="table-secondary" scope="col">First Name</th>
                                        <th class="table-secondary" scope="col">Last Name</th>
                                        <th class="table-secondary" scope="col">D O B</th>
                                        <th class="table-secondary" scope="col">Age</th>
                                        <th class="table-secondary" scope="col">Gender</th>
                                        <th class="table-secondary" scope="col">Blood Group</th>
                                        <th class="table-secondary" scope="col">Resident Of</th>
                                        <th class="table-secondary" scope="col">Disability</th>
                                        <th class="table-secondary" scope="col">Category </th>
                                        <th class="table-secondary" scope="col">Marital Status</th>
                                        {/* <th class="table-secondary" scope="col">Educational Details</th>
                                        <th class="table-secondary" scope="col">Resident of Maharashtralagate</th>
                                        <th class="table-secondary" scope="col">Types Of Disability</th>
                                        <th class="table-secondary" scope="col">Area of Disability</th> */}
                                        <th class="table-secondary" scope="col">BPL/APL</th>
                                        <th class="table-secondary" scope="col">Annual Income</th>
                                        <th class="table-secondary" scope="col">Business Category</th>
                                        {/* <th class="table-secondary" scope="col">Identity Proof</th>
                                        <th class="table-secondary" scope="col">Affidavith</th> */}
                                        <th class="table-secondary" scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {listSeller && listSeller?.map((item) => {
                                        return <tr key={item._id}>
                                            <td>{item?.seller?.applicationNo}</td>
                                            <td>{item?.seller?.applicationDate}</td>
                                            <td>{item?.seller?.udId_No}</td>
                                            <td>{item?.seller?.adhaarCard}</td>
                                            <td>{item?.seller?.bene_firstname}</td>
                                            <td>{item?.seller?.bene_lastname}</td>
                                            <td>{item?.seller?.dob}</td>
                                            <td>{item?.seller?.declareAge}</td>
                                            <td>{item?.seller?.gender}</td>
                                            <td>{item?.seller?.bloodGroup}</td>
                                            <td>{item?.seller?.residentOf}</td>
                                            <td>{item?.seller?.PerOfDis}%</td>
                                            <td>{item?.seller?.castCategory}</td>
                                            <td>{item?.seller?.maritalStatus}</td>
                                            <td>{item?.seller?.employmentDetail?.bpl}</td>
                                            <td>{item?.seller?.employmentDetail?.annualIncom}</td>
                                            <td>{item?.seller?.businessCategory?.name}</td>
                                            {/* <td><img src={item?.idProofFile?.url} alt="" style={{ width: '40px' }} /></td>
                                            <td><img src={item?.affidavith?.url} alt="" style={{ width: '40px' }} /></td> */}
                                            <td className="d-flex">

                                                <button type="button" onClick={() => handleDelete(item?.seller?._id)} className="btn btn-soft-danger btn-icon btn-circle btn-sm btn-circle-2" title="delete" fdprocessedid="yghhlt">
                                                    <i className="las la-trash icon-icon">
                                                    </i>
                                                </button>
                                                <Link className="ms-2 btn btn-soft-primary btn-icon btn-circle btn-sm me-2 btn-circle-2" title="View" to={`/admin/special-seller/details/${item?.seller?._id}`}>
                                                    {/* <i className="las la-eye">
                                    </i> */}
                                                    <GrView />
                                                </Link>
                                            </td>


                                        </tr>
                                    })}
                                </tbody>
                            </table>
                            <div className="aiz-pagination">
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bg-white text-center py-3 px-15px px-lg-25px mt-auto">
                </div>
            </div>
        </>
    )
}
export default SpecialSellerList