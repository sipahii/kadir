import React from 'react'
import AddRingSize from '../generalMaster/ringSize/addRingSize/AddRingSize'

function EditRingSizeComp() {
    return (
        <>
            <AddRingSize />
        </>
    )
}

export default EditRingSizeComp