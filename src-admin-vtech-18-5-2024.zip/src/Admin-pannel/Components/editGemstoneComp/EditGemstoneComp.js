import React from 'react'
import AddGemstonePage from '../../Pages/addGemstonePage'

function EditGemstoneComp() {
    return (
        <>
            <AddGemstonePage />
        </>
    )
}

export default EditGemstoneComp