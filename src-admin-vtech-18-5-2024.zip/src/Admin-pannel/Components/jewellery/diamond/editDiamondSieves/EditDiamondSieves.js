import React from 'react'
import AddDiamondSievesPage from '../../../../Pages/jewellery/diamond/addDiamondSieves/Index'

function EditDiamondSieves() {
    return (
        <>
            <AddDiamondSievesPage />
        </>
    )
}

export default EditDiamondSieves