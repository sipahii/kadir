import React from 'react'
import AddDiamondShapePage from '../../../../Pages/jewellery/diamond/addDiamondShape/Index'

function EditDiamondShape() {
    return (
        <>
            <AddDiamondShapePage />
        </>
    )
}

export default EditDiamondShape