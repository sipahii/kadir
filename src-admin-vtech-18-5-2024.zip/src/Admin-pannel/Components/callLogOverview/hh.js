<div className="row">
  <div>
    <div className="col-md-4">
      <div className="width border" style={{ width: 306, height: 104 }}>
        <p>Today's call</p>
        <hr className="border border-2 opacity-50 border-secondary" />
        <div className="row text-center">
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Inbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Outbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary">8</div>
            <span>Sms</span>
          </div>
        </div>
      </div>
    </div>
    <div className="col-md-4 mt-3">
      <div className="width border" style={{ width: 306, height: 104 }}>
        <p>Weekly calls</p>
        <hr className="border border-2 opacity-50 border-secondary" />
        <div className="row text-center">
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Inbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Outbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary">8</div>
            <span>Sms</span>
          </div>
        </div>
      </div>
    </div>
    <div className="col-md-4 mt-3">
      <div className="width border" style={{ width: 306, height: 104 }}>
        <p>Mounthly call</p>
        <hr className="border border-2 opacity-50 border-secondary" />
        <div className="row text-center">
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Inbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary">0</div>
            <span>Outbound</span>
          </div>
          <div className="col-4">
            <div className="text-primary" style={{ color: "blue" }}>
              8
            </div>
            <span>Sms</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div className="col-md-6">
    <div className="width border" style={{ width: 306, height: 104 }}>
      hello
    </div>
  </div>
</div>;
