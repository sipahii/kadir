import React from 'react'
import AddProductLookTagComp from '../addProductLookTagComp/AddProductLookTagComp'

function EditProductLookTagComp() {
    return (
        <>
            <AddProductLookTagComp />
        </>
    )
}

export default EditProductLookTagComp