import React from 'react'
import AddOccasion from '../generalMaster/occasion/addOccasion/AddOccasion'

function EditOccassionComp() {
    return (
        <>
            <AddOccasion />
        </>
    )
}

export default EditOccassionComp